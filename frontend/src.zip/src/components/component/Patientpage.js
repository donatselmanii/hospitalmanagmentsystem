import react from 'react'

export default function Patientpage(){
  return(
    <>
    <h1>Patienttt page</h1>
    </>
  );
}