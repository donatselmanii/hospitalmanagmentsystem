import react from 'react'

export default function Adminpage(){
  return(
    <>
    <h1>Adminnn pageee</h1>
    </>
  );
}