import react from 'react'

export default function Doctorpage(){
  return(
    <>
    <h1>Doctorrr pageee</h1>
    </>
  );
}